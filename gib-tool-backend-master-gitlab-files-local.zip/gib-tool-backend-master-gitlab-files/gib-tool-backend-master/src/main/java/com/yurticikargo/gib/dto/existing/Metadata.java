
package com.yurticikargo.gib.dto.existing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "optime"
})
public class Metadata {

    @JsonProperty("optime")
    private String optime;

    @JsonProperty("optime")
    public String getOptime() {
        return optime;
    }

    @JsonProperty("optime")
    public void setOptime(String optime) {
        this.optime = optime;
    }

    public Metadata withOptime(String optime) {
        this.optime = optime;
        return this;
    }

}
