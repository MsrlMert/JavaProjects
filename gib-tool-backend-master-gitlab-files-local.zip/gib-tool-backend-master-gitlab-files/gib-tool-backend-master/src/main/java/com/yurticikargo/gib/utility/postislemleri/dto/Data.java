
package com.yurticikargo.gib.utility.postislemleri.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import jakarta.annotation.Generated;


import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "toplam_genel",
    "posListeSize",
    "pageNo",
    "ay",
    "posBilgileriTable",
    "yil"
})
@Generated("jsonschema2pojo")
public class Data {

    @JsonProperty("toplam_genel")
    private String toplamGenel;
    @JsonProperty("posListeSize")
    private String posListeSize;
    @JsonProperty("pageNo")
    private String pageNo;
    @JsonProperty("ay")
    private String ay;
    @JsonProperty("posBilgileriTable")
    private List<PosBilgileriTable> posBilgileriTable = null;
    @JsonProperty("yil")
    private String yil;

    @JsonProperty("toplam_genel")
    public String getToplamGenel() {
        return toplamGenel;
    }

    @JsonProperty("toplam_genel")
    public void setToplamGenel(String toplamGenel) {
        this.toplamGenel = toplamGenel;
    }

    public Data withToplamGenel(String toplamGenel) {
        this.toplamGenel = toplamGenel;
        return this;
    }

    @JsonProperty("posListeSize")
    public String getPosListeSize() {
        return posListeSize;
    }

    @JsonProperty("posListeSize")
    public void setPosListeSize(String posListeSize) {
        this.posListeSize = posListeSize;
    }

    public Data withPosListeSize(String posListeSize) {
        this.posListeSize = posListeSize;
        return this;
    }

    @JsonProperty("pageNo")
    public String getPageNo() {
        return pageNo;
    }

    @JsonProperty("pageNo")
    public void setPageNo(String pageNo) {
        this.pageNo = pageNo;
    }

    public Data withPageNo(String pageNo) {
        this.pageNo = pageNo;
        return this;
    }

    @JsonProperty("ay")
    public String getAy() {
        return ay;
    }

    @JsonProperty("ay")
    public void setAy(String ay) {
        this.ay = ay;
    }

    public Data withAy(String ay) {
        this.ay = ay;
        return this;
    }

    @JsonProperty("posBilgileriTable")
    public List<PosBilgileriTable> getPosBilgileriTable() {
        return posBilgileriTable;
    }

    @JsonProperty("posBilgileriTable")
    public void setPosBilgileriTable(List<PosBilgileriTable> posBilgileriTable) {
        this.posBilgileriTable = posBilgileriTable;
    }

    public Data withPosBilgileriTable(List<PosBilgileriTable> posBilgileriTable) {
        this.posBilgileriTable = posBilgileriTable;
        return this;
    }

    @JsonProperty("yil")
    public String getYil() {
        return yil;
    }

    @JsonProperty("yil")
    public void setYil(String yil) {
        this.yil = yil;
    }

    public Data withYil(String yil) {
        this.yil = yil;
        return this;
    }

}
