
package com.yurticikargo.gib.dto.existing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "isyeriadres",
    "birimfaal",
    "isyerituru",
    "isibirakmatar",
    "subeadi",
    "subeno",
    "vdkodu",
    "isebaslamatar"
})
public class SUBEARRAY {

    @JsonProperty("isyeriadres")
    private String isyeriadres;
    @JsonProperty("birimfaal")
    private Integer birimfaal;
    @JsonProperty("isyerituru")
    private Integer isyerituru;
    @JsonProperty("isibirakmatar")
    private String isibirakmatar;
    @JsonProperty("subeadi")
    private String subeadi;
    @JsonProperty("subeno")
    private String subeno;
    @JsonProperty("vdkodu")
    private Integer vdkodu;
    @JsonProperty("isebaslamatar")
    private String isebaslamatar;

    @JsonProperty("isyeriadres")
    public String getIsyeriadres() {
        return isyeriadres;
    }

    @JsonProperty("isyeriadres")
    public void setIsyeriadres(String isyeriadres) {
        this.isyeriadres = isyeriadres;
    }

    public SUBEARRAY withIsyeriadres(String isyeriadres) {
        this.isyeriadres = isyeriadres;
        return this;
    }

    @JsonProperty("birimfaal")
    public Integer getBirimfaal() {
        return birimfaal;
    }

    @JsonProperty("birimfaal")
    public void setBirimfaal(Integer birimfaal) {
        this.birimfaal = birimfaal;
    }

    public SUBEARRAY withBirimfaal(Integer birimfaal) {
        this.birimfaal = birimfaal;
        return this;
    }

    @JsonProperty("isyerituru")
    public Integer getIsyerituru() {
        return isyerituru;
    }

    @JsonProperty("isyerituru")
    public void setIsyerituru(Integer isyerituru) {
        this.isyerituru = isyerituru;
    }

    public SUBEARRAY withIsyerituru(Integer isyerituru) {
        this.isyerituru = isyerituru;
        return this;
    }

    @JsonProperty("isibirakmatar")
    public String getIsibirakmatar() {
        return isibirakmatar;
    }

    @JsonProperty("isibirakmatar")
    public void setIsibirakmatar(String isibirakmatar) {
        this.isibirakmatar = isibirakmatar;
    }

    public SUBEARRAY withIsibirakmatar(String isibirakmatar) {
        this.isibirakmatar = isibirakmatar;
        return this;
    }

    @JsonProperty("subeadi")
    public String getSubeadi() {
        return subeadi;
    }

    @JsonProperty("subeadi")
    public void setSubeadi(String subeadi) {
        this.subeadi = subeadi;
    }

    public SUBEARRAY withSubeadi(String subeadi) {
        this.subeadi = subeadi;
        return this;
    }

    @JsonProperty("subeno")
    public String getSubeno() {
        return subeno;
    }

    @JsonProperty("subeno")
    public void setSubeno(String subeno) {
        this.subeno = subeno;
    }

    public SUBEARRAY withSubeno(String subeno) {
        this.subeno = subeno;
        return this;
    }

    @JsonProperty("vdkodu")
    public Integer getVdkodu() {
        return vdkodu;
    }

    @JsonProperty("vdkodu")
    public void setVdkodu(Integer vdkodu) {
        this.vdkodu = vdkodu;
    }

    public SUBEARRAY withVdkodu(Integer vdkodu) {
        this.vdkodu = vdkodu;
        return this;
    }

    @JsonProperty("isebaslamatar")
    public String getIsebaslamatar() {
        return isebaslamatar;
    }

    @JsonProperty("isebaslamatar")
    public void setIsebaslamatar(String isebaslamatar) {
        this.isebaslamatar = isebaslamatar;
    }

    public SUBEARRAY withIsebaslamatar(String isebaslamatar) {
        this.isebaslamatar = isebaslamatar;
        return this;
    }

}
