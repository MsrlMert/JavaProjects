package com.yurticikargo.gib.dto.request;

import jakarta.persistence.Column;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class GIBCellRequestDto {

    private String posBankVkn;
    private String posMemberCompany;
    private String posBankName;
    private String username;
    private double sum;

}
