package com.yurticikargo.gib.repository.enums;

public enum State {
    INACTIVE,ACTIVE;
}
