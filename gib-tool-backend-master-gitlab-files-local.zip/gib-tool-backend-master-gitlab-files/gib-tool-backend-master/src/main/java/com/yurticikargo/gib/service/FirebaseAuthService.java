package com.yurticikargo.gib.service;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.UserRecord;
import com.yurticikargo.gib.dto.request.RegisterRequestDto;
import com.yurticikargo.gib.dto.request.UpdateUserRequestDto;
import com.yurticikargo.gib.exception.ErrorType;
import com.yurticikargo.gib.exception.GIBExceptionManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import com.google.firebase.auth.UserRecord.*;

@Service
@RequiredArgsConstructor
public class FirebaseAuthService {
    public UserRecord registerUser(RegisterRequestDto dto) throws FirebaseAuthException {
        CreateRequest request = new CreateRequest()
                .setUid(dto.getUsername()) // Use the username as the unique user ID
                .setPassword(dto.getPassword())
                .setEmail(dto.getEmail())
                .setPhoneNumber(dto.getPhoneNumber())
                .setDisabled(false)
                .setEmailVerified(true)
                .setDisplayName(dto.getDisplayName());
        return FirebaseAuth.getInstance().createUser(request);
    }
    //signInWithEmailAndPassword için javascript ya da android uygulamada yapılabiliyor
    public UserRecord loginUser(String username, String password) throws FirebaseAuthException {
        UserRecord userRecord = FirebaseAuth.getInstance().getUser(username);
        if (userRecord == null) {
            throw new GIBExceptionManager(ErrorType.USER_IS_NOT_FOUND);
        }
        return userRecord;
    }

    public UserRecord updateUserInfo(UpdateUserRequestDto dto)throws FirebaseAuthException {
        UserRecord userRecord = FirebaseAuth.getInstance().getUser(dto.getUsername());
        if (userRecord == null) {
            throw new GIBExceptionManager(ErrorType.USER_IS_NOT_FOUND);
        }
        UpdateRequest request = new UpdateRequest(dto.getUsername())
                .setDisplayName(dto.getDisplayName()==null ? userRecord.getDisplayName() : dto.getDisplayName())
                .setPhoneNumber(dto.getPhoneNumber()==null ? userRecord.getPhoneNumber() : dto.getPhoneNumber())
                .setPhotoUrl(dto.getPhotoUrl()==null ? userRecord.getPhotoUrl() : dto.getPhotoUrl());

        return FirebaseAuth.getInstance().updateUser(request);
    }

}










