package com.yurticikargo.gib.exception;

import lombok.Getter;

@Getter
public class GIBExceptionManager extends RuntimeException {
    private final ErrorType errorType;

    public GIBExceptionManager(ErrorType errorType){
        super(errorType.getMessage());
        this.errorType = errorType;
    }

    public GIBExceptionManager(ErrorType errorType, String message){
        super(message);
        this.errorType = errorType;
    }
}
