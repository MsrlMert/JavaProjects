# http://localhost:8095/swagger-ui/index.html#/
<h4>When project is started, all APIs could be test by swagger link above.<h4>