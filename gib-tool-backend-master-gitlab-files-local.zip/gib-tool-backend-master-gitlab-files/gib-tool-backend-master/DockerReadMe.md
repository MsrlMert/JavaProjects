# DOCKER KULLANIMI

Proje öncelikle clean edilmeli ve build alınmalıdır bagimliklar ile birlikte.
## IMAGE OLUSTURMA
    docker build --build-arg JAR_FILE=<build path >-t <image name> .
    docker build --build-arg JAR_FILE=build/libs/gib-tool-0.0.1-SNAPSHOT.jar -t gibbackend:latest .
    build path: servisimizden build alindidinda olusan jar dosyasinin konumu
    image name:  <tag>:<version> gibbackend:latest
## IMAGE UZERINDEN CONTAINER CALISTIRMA
    docker run -d -p <outport>:<inport> <tag>:<version>
    docker run -d -p 8095:8095 gibbackend:latest
    inport: application yml da uygulamanin ayaga kalktigi port
    outport: containerin disariya acildigi port istekler bu porta gelecek bu port ic porta yonlendirecek