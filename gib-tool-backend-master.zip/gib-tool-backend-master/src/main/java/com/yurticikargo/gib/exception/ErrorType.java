package com.yurticikargo.gib.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum ErrorType {
    INTERNAL_ERROR(2000, "Internal Server Error", INTERNAL_SERVER_ERROR),
    BAD_REQUEST_ERROR(2001, "Invalid Parameter Error", BAD_REQUEST),

    FILE_NULL(1001, "File is null", INTERNAL_SERVER_ERROR),
    PERIOD_IS_EXIST(1002, "This period is exist on database", INTERNAL_SERVER_ERROR),
    PERIOD_IS_NOT_EXIST(1003, "This period is NOT exist on database", INTERNAL_SERVER_ERROR),
    USER_IS_NOT_FOUND(1004, "This USER is NOT exist", INTERNAL_SERVER_ERROR);




    private int code;
    private String message;
    HttpStatus httpStatus;

}