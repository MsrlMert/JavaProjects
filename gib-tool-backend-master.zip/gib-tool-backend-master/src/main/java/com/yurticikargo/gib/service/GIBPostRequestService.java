package com.yurticikargo.gib.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import com.yurticikargo.gib.dto.request.GIBRequestDto;
import com.yurticikargo.gib.dto.response.GIBCellResponseDto;
import com.yurticikargo.gib.utility.postislemleri.dto.PosBilgileriTable;
import com.yurticikargo.gib.utility.postislemleri.dto.PosIslemleriResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


@Service
@RequiredArgsConstructor
public class GIBPostRequestService {

    private final GIBPostService gibCellService;

//TODO : Bu kısmı gerçek deneme de aç

//    public List<GIBCellResponseDto> saveAllDataToDB(GIBRequestDto dto) throws Throwable  {
//        // Set variables from DTO
//        String token = dto.getToken();
//        String year = dto.getDate().substring(0, 4);
//        String month = dto.getDate().substring(5);
//
//
//        Unirest.setTimeouts(0, 0);
//
//        int pageNum   = 1;
//        int totalRowCount = 0;
//        PosIslemleriResponse readValue = fetchPageData(String.valueOf(pageNum), token, year, month);
//
//        Integer rowCount 	           =  Integer.parseInt(readValue.getData().getPosListeSize());
//
//        ExcelGenerator excelGenerator = new ExcelGenerator() ;
//
//        excelGenerator.writeHeader();
//        List<PosBilgileriTable> finalList = new ArrayList<>();
//
//        while (totalRowCount < rowCount) {
//
//            readValue = fetchPageData(String.valueOf(pageNum++), token, year, month);
//
//            Data data = readValue.getData();
//
//            List<PosBilgileriTable> posBilgileriTable = data.getPosBilgileriTable();
//
//            finalList.addAll(posBilgileriTable);
//
//            totalRowCount = totalRowCount+ posBilgileriTable.size();
//        }
//        return gibCellService.saveAll(finalList,year,month);
//    }

    public List<GIBCellResponseDto> saveAllDataToDB(GIBRequestDto dto) throws Throwable  {
        String token = dto.getToken();
        String year = dto.getDate().substring(0, 4);
        String month = dto.getDate().substring(5);

        PosBilgileriTable element1 = new PosBilgileriTable("25000","ING BANK","655299824","4810058590");
        PosBilgileriTable element2 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element3 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element4 = new PosBilgileriTable("78900","HELLO BANK","655299824","4810058590");
        PosBilgileriTable element5 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element6 = new PosBilgileriTable("90000","DENIZ","655299824","4810058590");
        PosBilgileriTable element7 = new PosBilgileriTable("56700","ING BANK","655299824","4810058590");
        PosBilgileriTable element8 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element9 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element10 = new PosBilgileriTable("25000","HELLO BANK","655299824","4810058590");
        PosBilgileriTable element11 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element12 = new PosBilgileriTable("85000","DENIZ","655299824","4810058590");
        PosBilgileriTable element13 = new PosBilgileriTable("25000","ING BANK","655299824","4810058590");
        PosBilgileriTable element14 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element15 = new PosBilgileriTable("28000","DENIZ","655299824","4810058590");
        PosBilgileriTable element16 = new PosBilgileriTable("29990","DENIZ","655299824","4810058590");
        PosBilgileriTable element17 = new PosBilgileriTable("25000","ING BANK","655299824","4810058590");
        PosBilgileriTable element18 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element19 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element20 = new PosBilgileriTable("89000","HELLO BANK","655299824","4810058590");
        PosBilgileriTable element21 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element22 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element23 = new PosBilgileriTable("90000","DENIZ","655299824","4810058590");
        PosBilgileriTable element24 = new PosBilgileriTable("25000","HELLO BANK","655299824","4810058590");
        PosBilgileriTable element25 = new PosBilgileriTable("45000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element26 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element27 = new PosBilgileriTable("25000","ING BANK","655299824","4810058590");
        PosBilgileriTable element28 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element29 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element30 = new PosBilgileriTable("56770","HELLO BANK","655299824","4810058590");
        PosBilgileriTable element31 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element32 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element33 = new PosBilgileriTable("67800","ING BANK","655299824","4810058590");
        PosBilgileriTable element34 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element35 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element36 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element37 = new PosBilgileriTable("25000","ING BANK","655299824","4810058590");
        PosBilgileriTable element38 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element39 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");
        PosBilgileriTable element40 = new PosBilgileriTable("25000","HELLO BANK","655299824","4810058590");
        PosBilgileriTable element41 = new PosBilgileriTable("25000","UNICREDIT","655299824","4810058590");
        PosBilgileriTable element42 = new PosBilgileriTable("25000","DENIZ","655299824","4810058590");

        List<PosBilgileriTable> finalList = new ArrayList<>(Arrays.asList(
                element1, element2, element3, element4, element5, element6, element7, element8,
                element9, element10, element11, element12, element13, element14, element15,
                element16, element17, element18, element19, element20, element21, element22,
                element23, element24, element25, element26, element27, element28, element29,
                element30, element31, element32, element33, element34, element35, element36,
                element37, element38, element39, element40, element41, element42
        ));
        return gibCellService.saveAll(finalList,year,month);
    }


    private static PosIslemleriResponse fetchPageData(String pageNumber, String token, String year, String month)
            throws UnsupportedEncodingException, UnirestException, JsonProcessingException, JsonMappingException {
        String jp ="{\"sayfa\":%s,\"ay1\":\"%s\",\"yil1\":\"%s\"}";
        String jpParam = URLEncoder.encode(String.format(jp, pageNumber,month,year), "UTF-8");

        HttpResponse<String> response =
                Unirest.get("https://intvrg.gib.gov.tr/intvrg_server/dispatch?cmd=posBilgileriIslemleri_posSonuc&callid=b9c09e173bfaa-13&token="+token+"&jp="+jpParam)
                        .asString();

        ObjectMapper objectMapper = new ObjectMapper();
        String body = response.getBody();

        System.out.println(body);

        PosIslemleriResponse readValue = objectMapper.readValue(body, PosIslemleriResponse.class);
        return readValue;
    }

}