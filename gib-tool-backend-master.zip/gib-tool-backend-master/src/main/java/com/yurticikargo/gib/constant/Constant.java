package com.yurticikargo.gib.constant;

import java.time.format.DateTimeFormatter;

public class Constant {
    //APIs
    public static final String EXCEL = "api/v1/excel";
    public static final String GIBPOS = "api/v1/gibpos";
    public static final String AUTH = "api/v1/auth";

    public static final String GETFILE = "/getfile";
    public static final String LOGIN = "/login";
    public static final String UPDATE = "/update";
    public static final String REGISTER = "/register";
    public static final String GET_OR_FIRST_REQUEST_FILE = "/get-or-first-request-file";
}
