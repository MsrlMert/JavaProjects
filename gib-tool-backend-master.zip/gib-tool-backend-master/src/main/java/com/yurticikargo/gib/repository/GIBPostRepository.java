package com.yurticikargo.gib.repository;

import com.yurticikargo.gib.repository.entity.GIBPost;
import com.yurticikargo.gib.repository.entity.GIBPeriod;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GIBPostRepository extends JpaRepository<GIBPost,Long> {
    Optional<List<GIBPost>> findAllOptionalByGibPeriod(GIBPeriod period);
}
