package com.yurticikargo.gib.dto.existing;



import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "data",
    "metadata"
})
public class Response {

	@JsonProperty("data")
	private Data data;
	@JsonProperty("metadata")
	private Metadata metadata;

	@JsonProperty("data")
	public Data getData() {
		return data;
	}

	@JsonProperty("data")
	public void setData(Data data) {
		this.data = data;
	}

	public Response withData(Data data) {
		this.data = data;
		return this;
	}

	@JsonProperty("metadata")
	public Metadata getMetadata() {
		return metadata;
	}

	@JsonProperty("metadata")
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

	public Response withMetadata(Metadata metadata) {
		this.metadata = metadata;
		return this;
	}

}
