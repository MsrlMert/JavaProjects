package com.yurticikargo.gib.utility;

import com.yurticikargo.gib.service.GIBPostService;
import com.yurticikargo.gib.utility.postislemleri.dto.PosBilgileriTable;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataImpl {

    private final GIBPostService service;

    // TODO: Test aşaması bittiğinde default verilerin geldiği bu method disabled yapılmalıdır, ve YML dosyası create-drop update olarak revize edilmelidir.
    @PostConstruct
    private  void create(){
        init();
    }

    private void init() {
        PosBilgileriTable element1 = new PosBilgileriTable("25000","TÜRKİYE İŞ BANKASI ANONİM ŞİRKETİ","655299824","4810058590");
        PosBilgileriTable element2 = new PosBilgileriTable("25000","YAPI KREDI","655299824","4810058590");
        PosBilgileriTable element3 = new PosBilgileriTable("25000","GARANTI","655299824","4810058590");
        PosBilgileriTable element4 = new PosBilgileriTable("25000","AKBANK","655299824","4810058590");
        PosBilgileriTable element5 = new PosBilgileriTable("25000","QBN BANK","655299824","4810058590");

        List<PosBilgileriTable> list = new ArrayList<>();
        list.add(element1);
        list.add(element2);
        list.add(element3);
        list.add(element4);
        list.add(element5);

        service.saveAll(list,"2023","06");
    }
}