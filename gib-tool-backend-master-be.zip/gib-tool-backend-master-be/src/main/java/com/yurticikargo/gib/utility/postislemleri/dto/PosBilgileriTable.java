
package com.yurticikargo.gib.utility.postislemleri.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import jakarta.annotation.Generated;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "toplam",
    "pos_banka_adi",
    "pos_uye_isy",
    "pos_banka_vkn"
})
@Generated("jsonschema2pojo")
public class PosBilgileriTable {

    @JsonProperty("toplam")
    private String toplam;
    @JsonProperty("pos_banka_adi")
    private String posBankaAdi;
    @JsonProperty("pos_uye_isy")
    private String posUyeIsy;
    @JsonProperty("pos_banka_vkn")
    private String posBankaVkn;

    @JsonProperty("toplam")
    public String getToplam() {
        return toplam;
    }

    @JsonProperty("toplam")
    public void setToplam(String toplam) {
        this.toplam = toplam;
    }

    public PosBilgileriTable withToplam(String toplam) {
        this.toplam = toplam;
        return this;
    }
    //TODO: delete
    public PosBilgileriTable(String toplam, String posBankaAdi, String posUyeIsy, String posBankaVkn) {
        this.toplam = toplam;
        this.posBankaAdi = posBankaAdi;
        this.posUyeIsy = posUyeIsy;
        this.posBankaVkn = posBankaVkn;
    }


    @JsonProperty("pos_banka_adi")
    public String getPosBankaAdi() {
        return posBankaAdi;
    }

    @JsonProperty("pos_banka_adi")
    public void setPosBankaAdi(String posBankaAdi) {
        this.posBankaAdi = posBankaAdi;
    }

    public PosBilgileriTable withPosBankaAdi(String posBankaAdi) {
        this.posBankaAdi = posBankaAdi;
        return this;
    }

    @JsonProperty("pos_uye_isy")
    public String getPosUyeIsy() {
        return posUyeIsy;
    }

    @JsonProperty("pos_uye_isy")
    public void setPosUyeIsy(String posUyeIsy) {
        this.posUyeIsy = posUyeIsy;
    }

    public PosBilgileriTable withPosUyeIsy(String posUyeIsy) {
        this.posUyeIsy = posUyeIsy;
        return this;
    }

    @JsonProperty("pos_banka_vkn")
    public String getPosBankaVkn() {
        return posBankaVkn;
    }

    @JsonProperty("pos_banka_vkn")
    public void setPosBankaVkn(String posBankaVkn) {
        this.posBankaVkn = posBankaVkn;
    }

    public PosBilgileriTable withPosBankaVkn(String posBankaVkn) {
        this.posBankaVkn = posBankaVkn;
        return this;
    }

}
