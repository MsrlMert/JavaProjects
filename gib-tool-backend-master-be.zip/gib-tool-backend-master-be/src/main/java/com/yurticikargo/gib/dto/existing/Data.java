
package com.yurticikargo.gib.dto.existing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "PAGENUM",
    "TOPLAMSUBESAY",
    "vergiNo",
    "SUBEARRAY",
    "sorguVD"
})
public class Data {

    @JsonProperty("PAGENUM")
    private int pAGENUM;
    @JsonProperty("TOPLAMSUBESAY")
    private int tOPLAMSUBESAY;
    @JsonProperty("vergiNo")
    private String vergiNo;
    @JsonProperty("SUBEARRAY")
   
    private List<SUBEARRAY> sUBEARRAY = null;
    @JsonProperty("sorguVD")
    private String sorguVD;

    @JsonProperty("PAGENUM")
    public int getPAGENUM() {
        return pAGENUM;
    }

    @JsonProperty("PAGENUM")
    public void setPAGENUM(int pAGENUM) {
        this.pAGENUM = pAGENUM;
    }

    public Data withPAGENUM(int pAGENUM) {
        this.pAGENUM = pAGENUM;
        return this;
    }

    @JsonProperty("TOPLAMSUBESAY")
    public int getTOPLAMSUBESAY() {
        return tOPLAMSUBESAY;
    }

    @JsonProperty("TOPLAMSUBESAY")
    public void setTOPLAMSUBESAY(int tOPLAMSUBESAY) {
        this.tOPLAMSUBESAY = tOPLAMSUBESAY;
    }

    public Data withTOPLAMSUBESAY(int tOPLAMSUBESAY) {
        this.tOPLAMSUBESAY = tOPLAMSUBESAY;
        return this;
    }

    @JsonProperty("vergiNo")
    public String getVergiNo() {
        return vergiNo;
    }

    @JsonProperty("vergiNo")
    public void setVergiNo(String vergiNo) {
        this.vergiNo = vergiNo;
    }

    public Data withVergiNo(String vergiNo) {
        this.vergiNo = vergiNo;
        return this;
    }

    @JsonProperty("SUBEARRAY")
    public List<SUBEARRAY> getSUBEARRAY() {
        return sUBEARRAY;
    }

    @JsonProperty("SUBEARRAY")
    public void setSUBEARRAY(List<SUBEARRAY> sUBEARRAY) {
        this.sUBEARRAY = sUBEARRAY;
    }

    public Data withSUBEARRAY(List<SUBEARRAY> sUBEARRAY) {
        this.sUBEARRAY = sUBEARRAY;
        return this;
    }

    @JsonProperty("sorguVD")
    public String getSorguVD() {
        return sorguVD;
    }

    @JsonProperty("sorguVD")
    public void setSorguVD(String sorguVD) {
        this.sorguVD = sorguVD;
    }

    public Data withSorguVD(String sorguVD) {
        this.sorguVD = sorguVD;
        return this;
    }

}
