package com.yurticikargo.gib.dto.request;
import jakarta.validation.constraints.*;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class GIBRequestDto {

    String token;
    @NotBlank
    @NotNull
    String date;
}