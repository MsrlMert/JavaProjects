package com.yurticikargo.gib.repository.enums;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

public enum SubeFaaliyetDurumu {

	Fark(1,"Faal"), Terk(2,"Terk");

	private Integer code;

	private String name;

	
	public Integer getCode() {
		return code;
	}



	private SubeFaaliyetDurumu(Integer code,String name) {
		this.code = code;
		this.name = name;
	}
	
	


	public String getName() {
		return name;
	}



	public void setCode(Integer code) {
		this.code = code;
	}




	private static final Map<Integer, SubeFaaliyetDurumu> lookup = new HashMap<Integer, SubeFaaliyetDurumu>();

	public static SubeFaaliyetDurumu get(Integer faal) {
		return lookup.get(faal);
	}

	static {
		for (SubeFaaliyetDurumu s : EnumSet.allOf(SubeFaaliyetDurumu.class))
			lookup.put(s.getCode(), s);
	}
	
	
}
