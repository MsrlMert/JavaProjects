package com.yurticikargo.gib.service.excelManager;

import com.yurticikargo.gib.utility.postislemleri.dto.PosBilgileriTable;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

public class ExcelGenerator {

//    private List < PosBilgileriTable > studentList;
    private XSSFWorkbook workbook;
    private XSSFSheet sheet;

    public ExcelGenerator() {
        workbook = new XSSFWorkbook();
    }
    
    public  void writeHeader() {
        sheet = workbook.createSheet("gib_pos_islemleri");
        Row row = sheet.createRow(0);
        CellStyle style = workbook.createCellStyle();
        XSSFFont font   = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(16);
        style.setFont(font);
        createCell(row, 0, "pos_banka_vkn", style);
        createCell(row, 1, "pos_uye_isyeri", style);
        createCell(row, 2, "pos_banka_adi", style);
        createCell(row, 3, "toplam", style);
    }
    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
//        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (valueOfCell instanceof Integer) {
            cell.setCellValue((Integer) valueOfCell);
        } else if (valueOfCell instanceof Long) {
            cell.setCellValue((Long) valueOfCell);
        } else if (valueOfCell instanceof String) {
            cell.setCellValue((String) valueOfCell);
        } else {
            cell.setCellValue((Boolean) valueOfCell);
        }
        cell.setCellStyle(style);
    }
   
    public void writeLines(List<PosBilgileriTable> studentList) {
        int rowCount = 1;
        CellStyle style = workbook.createCellStyle();
        XSSFFont font   = workbook.createFont();
        font.setFontHeight(14);
        style.setFont(font);
       
        for (PosBilgileriTable record: studentList) {
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;
            createCell(row, columnCount++, record.getPosBankaVkn(), style);
            createCell(row, columnCount++, record.getPosUyeIsy(), style);
            createCell(row, columnCount++, record.getPosBankaAdi(), style);
            createCell(row, columnCount++, record.getToplam(), style);
        }
    }
    
    public void generateExcelFile(String fileName) throws IOException {

        FileOutputStream fos = new FileOutputStream(fileName);
        workbook.write(fos);
        workbook.close();

        fos.close();
    }
    // This method is created not to output the workbook instead returning to API
    public Workbook generateExcelFile() throws IOException {
        return workbook;

    }
    
}