package com.yurticikargo.gib.repository.entity;

import com.yurticikargo.gib.repository.enums.State;
import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Builder
@Table(name = "GIB_POST_REQUEST")
public class GIBPost {

    @Id
    @GeneratedValue
    @Column(name = "ID")
    private Long id;

    @Column(name = "POS_BANK_VKN")
    private String posBankVkn;

    @Column(name = "POS_MEMBER_COMPANY")
    private String posMemberCompany;

    @Column(name = "POS_BANK_NAME")
    private String posBankName;

    @Column(name = "SUM")
    private double sum;

    @ManyToOne
    @JoinColumn(name="PERIOD_ID", nullable=false)
    private GIBPeriod gibPeriod;


    //sub info
    @Column(name = "CREATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createTime;
    @Column(name = "UPDATE_TIME")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updateTime;
    @Column(name = "STATE")
    @Enumerated(EnumType.ORDINAL)
    private State state;

    @PrePersist
    public void prePersist() {
        setCreateTime(new Date());
        setState(State.ACTIVE);
    }

    @PreUpdate
    public void preUpdate() {
        setUpdateTime(new Date());
    }
}
