<template>
  <h1>Sayfa Bulunamadı!</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>