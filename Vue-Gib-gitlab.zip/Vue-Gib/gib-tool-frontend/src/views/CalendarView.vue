<template>
    <Navbar :userInfo="userName" />
    <div class="container">

        <!-- Event Selection -->
        <div class="row mt-5">
            <div class="col-3">
                <p class="mx-auto p-2 rounded-2" style="background-color: rgb(221, 221, 221);">Drag & Drop Event</p>
                <div class="table-responsive" style="height:250px;">
                    <ul class="table">
                        <li draggable="true" :data-id="index" v-for="(row, index) in eventsList" :key="index" style="list-style-type: none;">
                            <p  class="bg-warning rounded-2 p-2"> {{ row }}</p>
                        </li>
                    </ul>
                </div>

                <div class="event-bottom mt-4 ">
                    <button class="w-100 rounded-3 p-1"
                        style="background-color: rgba(231, 151, 70, 0.836); color: white;">Add Category</button>
                </div>
            </div>

            <div class="col-9">

                <div class="card flex justify-content-center " style="background-color: rgb(231, 231, 213);">
                    <Calendar v-model="date" inline style="height: 550px;" :firstDayOfWeek="2" @date-select="handleDayClick"/>
                </div>
            </div>

        </div>
    </div>
</template>
  

<script>
import Navbar from '../components/NavBar.vue'
import Dialog from 'primevue/dialog';
import { ref } from "vue";
const dates = ref();


export default {
    components: {
        Navbar,
        Dialog
    },
    data() {
        return {
            currentDate: new Date(),
            userName: '',
            eventsList: ["Event1", "Event2", "Event3", "Event1", "Event2", "Event3", "Event1", "Event2", "Event3", "Event1", "Event2", "Event3"],

        };
    },
    computed: {
        currentMonth() {
            return this.currentDate.toLocaleString("default", { month: "long", year: "numeric" });
        },
        daysInMonth() {
            const days = [];
            const totalDays = new Date(this.currentDate.getFullYear(), this.currentDate.getMonth() + 1, 0).getDate();
            for (let i = 1; i <= totalDays; i++) {
                days.push(i);
            }
            return days;
        },
    },
    methods: {
        prevMonth() {
            this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        },
        nextMonth() {
            this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        },

        handleDayClick(clickedDate) {
            console.log('Tıklanılan Gün ' + clickedDate);
        }
    },
    mounted() {
        const data = this.$route.meta.data;
        this.userName = data['userInfo'];

        for (let index = 0; index < this.eventsList.length; index++) {
            const element = this.eventsList[index];

            console.log("Element : " + element + "\n");

        }

    },
};
</script>
  
<script setup>
import { ref } from "vue";

const dates = ref();
</script>

<style>
.calendar-container {
    font-family: Arial, sans-serif;
    width: 300px;
    margin: auto;
}

.calendar-header {
    padding: 10px;
}

.calendar-day {
    width: 40px;
    height: 40px;
    line-height: 40px;
    border: 1px solid #ccc;
    cursor: pointer;
}

.calendar-day:hover {
    background-color: #f8f9fa;
}
</style>
  


